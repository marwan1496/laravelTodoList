@extends('layouts.app')

@section('content')
  <h1>Todos</h1>
  @if(count($todosselect) > 0)
    @foreach($todosselect as $todo)

    <div class="card card-body bg-light">
      <h3><a href="todo/{{$todo->id}}">{{$todo->text}} </a><span class="badge badge-danger">{{$todo->due}}</span></h3>
    </div>
    @endforeach
  @endif
@endsection
