<?php $__env->startSection('content'); ?>
  <h1>Todos</h1>
  <?php if(count($todosselect) > 0): ?>
    <?php $__currentLoopData = $todosselect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card card-body bg-light">
      <h3><a href="todo/<?php echo e($todo->id); ?>"><?php echo e($todo->text); ?> </a><span class="badge badge-danger"><?php echo e($todo->due); ?></span></h3>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>