;

<?php $__env->startSection('content'); ?>

<h1>Edit Todo</h1>
<a href="/todo/<?php echo e($todo->id); ?>" class="btn btn-secondary">Go Back</a>
<?php echo Form::open(['action' => ['TodosController@update',$todo->id],'method' => 'POST']); ?>

    <?php echo e(Form::bsText('text',$todo->text)); ?>

    <?php echo e(Form::bsTextArea('body',$todo->body)); ?>

    <?php echo e(Form::bsText('due',$todo->due)); ?>

    <?php echo e(Form::hidden('_method','PUT')); ?>

    <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>